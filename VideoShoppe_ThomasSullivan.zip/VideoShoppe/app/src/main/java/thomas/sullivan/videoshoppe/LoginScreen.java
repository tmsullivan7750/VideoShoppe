package thomas.sullivan.videoshoppe;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.app.AlertDialog;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.text.InputType;

public class LoginScreen extends AppCompatActivity {

    UserDatabase usersDatabase;
    EditText editUsername,editPassword;
    Button btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_screen);
        usersDatabase = new UserDatabase(this);

        // DEBUGGING
        // Removes current database
       // usersDatabase.wipeDatabase();

        editUsername = (EditText)findViewById(R.id.editText_Username);
        editPassword = (EditText)findViewById(R.id.editText_Password);
        btnLogin = (Button)findViewById(R.id.button_Login);
        login();

        // DEBUGGING
        // ADD ADMIN TO DATABASE
        // boolean isInserted = usersDatabase.createUser("TEST ID", "TEST LAST NAME", "TEST FIRST NAME", "Admin", "Admin", "Yes");

    }

    public void login()
    {
        btnLogin.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        String usernameEntry = editUsername.getText().toString();
                        String passwordEntry = editPassword.getText().toString();

                        Toast.makeText(LoginScreen.this,"Username: "+usernameEntry+" & Password: "+passwordEntry,Toast.LENGTH_LONG).show();

                        /* NOT WORKING ATM
                        if(usernameEntry.equalsIgnoreCase(""))
                        {
                            usernameEntry = "null";
                        }

                        //DEBUGGING
                        //CHECKS STRINGS TO SEE IF USER ENTRY IS CORRECT
                        //Toast.makeText(LoginScreen.this,usernameEntry+" + "+passwordEntry,Toast.LENGTH_LONG).show();

                        boolean userMatch = usersDatabase.searchUsername(usernameEntry);

                        if(userMatch == true)
                        {
                            boolean passMatch = usersDatabase.searchPassword(usernameEntry,passwordEntry);
                            if(passMatch == true)
                            {
                                Toast.makeText(LoginScreen.this,"Login Successful",Toast.LENGTH_LONG).show();
                            }
                            else
                            {
                                Toast.makeText(LoginScreen.this,"Invalid Password",Toast.LENGTH_LONG).show();
                            }

                        }
                        else
                        {
                            Toast.makeText(LoginScreen.this,"Invalid Username",Toast.LENGTH_LONG).show();
                        }
                        */
                    }
                }
        );
    }

}
